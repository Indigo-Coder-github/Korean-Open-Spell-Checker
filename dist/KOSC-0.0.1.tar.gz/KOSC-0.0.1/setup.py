from setuptools import setup, find_packages

setup(
    name="KOSC",
    version="0.0.1",
    description="This is open source project of Korean spell checker made by Python",
    author="Indigo-Coder",
    author_email="hjs40111@gmail.com",
    url='https://github.com/Indigo-Coder-github/Korean-Open-Spell-Checker',
    install_requires=[],
    keywords=[],
    python_requires='>=3.6'
)